"""
Test module for ko_ak_zad1.py
"""

from better import *
import unittest
import random

class tests(unittest.TestCase):

    def test_correctValues(self):
        self.assertEqual(rank([1,2,5,6],6),47)
        self.assertEqual(unrank(47,6),[1,2,5,6])
        self.assertEqual(unrank(47 ,6),[1,2,5,6])
        self.assertEqual(successor(47,6), [1,3,4,5] )

    def test_randomCorrectValues(self):
        self.n = 12
        self.x = list(range(1,int(random.randrange(self.n+1))))
        self.y = random.randrange(self.n)
        self.assertEqual( unrank(int(rank(self.x,self.n)),self.n) , self.x[1:])
        self.assertEqual( rank(unrank(self.y,self.n),self.n) , self.y )

    def test_incorrectRankValues_test(self):
        with self.assertRaises(AssertionError):
            self.n = 2
            self.rank = -1
            self.assertEqual(unrank(self.rank, self.n),1)



    def test_ExtremeValues_predeccessor_successor(self):
        self.assertEqual(predecessor(0, 2), None)
        self.assertEqual(successor(3, 2), None)


    def test_predeccessor(self):
        self.rank = random.randint(1,2**4)
        self.assertEqual(predecessor(self.rank, 8), unrank(self.rank -1 ,8))

    def test_successor(self):
        self.n = 6
        self.rank = random.randint(1,(2**self.n)-1)
        self.assertEqual(successor(self.rank,self.n) , unrank(self.rank + 1, self.n))

