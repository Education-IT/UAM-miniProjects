# Mamy zbiór A który ma n elementów ( |A| = n )
# A = {1, 2, 3, ..., n}
# Kolejność jest następująca wszystkich podzbiorów:
# Dla n =3
# zbiór pusty, {1} , {2} , {3} , {1,2} , {1,3} , {2,3} , {1,2,3}


def subsets(numbers):
    if numbers == []:
        return [[]]
    x = subsets(numbers[1:])
    return x + [[numbers[0]] + y for y in x]


def subsets_of_given_size(numbers, n):
    return [x for x in subsets(numbers) if len(x) == n]


def Newton(n, k):
    Wynik = 1
    for i in range(1, k + 1):
        Wynik = Wynik * (n - i + 1) / i
    return Wynik


# 3 powyższe funkcje wzięte ze strony https://www.geeksforgeeks.org/python-program-to-get-all-subsets-of-given-size-of-a-set/


# --------------------------------------------------------------
# RANK

def ranked(s, n):
    rank = 0

    # Liczymy liczbę elementów w każdy podzbiorze od składający się z 0 do len(s)-1 elementów
    for i in range(len(s)):
        rank += Newton(n, i) # Symbol Newtora ( N po I elementów ) = ile jest zbiorów i elementowych składającyhc się z cyfr od 1 do n

    if len(s) == n: #jeżeli liczba elememnetów w "zbiorze" jest równa n to wypisz ten zbiór.. bo taki jest tylko jeden.
        return rank

    else:
        x = subsets_of_given_size(list(range(1, n + 1)), len(s))  # Tworzy listę wszystkich podzbiorów konkretnego rozmiaru - składających się z cyfr od jeden do n, o długości len(s)
        x.reverse() #odwracamy listę aby była w kolejności leksykograficznej
        y = x.index(s) #sprawdzamy na jakim indeksie znajduje z tych wszytskich podzbiorów znajduje się zbiór dany przez użytkownika
        rank += y # dodajemy do liczby rankingowej index
        return rank


# --------------------------------------------------------------
# --------------------------------------------------------------
# --------------------------------------------------------------


def op(rank, n, operation): #Dla zmniejsza ilosci kodu wybieramy za pomocą stringa jaką operacja chcemy wykonać - dlatego że do tych 3 przyda nam się ten sam początek
    i = n
    suma = (2 ** n) - 1 # suma wszytskich możliwych liczb rankingowych.
    while suma > rank: # tak długo jak suma jest większa niż liczba rankingowa tak długo zmniejszamy sume o liczbę podzbiorów wyższego rzędu niż ten którego szukamy
        i -= 1
        suma -= Newton(n, i) #jak pętla się kończy to zmienna i wyznacza nam ilo elementowe podzbiory będziemy badać

    x = subsets_of_given_size(list(range(1, n + 1)), i) #tworzymy wszystkie możliwe i-elementowe podzbiory składające się z elementów od 1 do n,
    x.reverse() #odwracamy listę aby była w porządku leksykograficznm
    index = rank - int(suma) #różnica pomiędzy sumą a liczbą rankingową daje nam indeks pod którym w liscie x znajduje się interesujący (szukany przez nas) poddzbiór
    y = x[index]

    # --------------------------------------------------------------
    # UNRANKED

    if operation == "unranked": #wszytskie powyższe operacje wyznaczają nam zbiór dany konkretną liczbą rankingową
        return y

    # --------------------------------------------------------------
    # SUCCESSOR - następnik

    elif operation == "successor":

        if len(y) == n: #jeśli długość naszego zbioru jest równa możliwej liczbie elementów z których może się składać - oznacza to że nie istnieje coś takiego jak następnik
            return None

        elif x.index(y) + 1 < len(x): # pracując na i-elementowych podzbiorach - sprawdzamy, czy po dodaniu do indeksu jedynki - przekroczymy długość listy x - jeśli nie... to zmieniamy indeks na tym zbiorze i otrzymujemy następnik... ale jeśli wyjdziemy poza długość listo to oznacza że wyszliśmy spoza opcji i-elementowego zbioru!
            return x[index + 1]

        else: # jeśli wyszliśmy poza i-elementowy zbiór to wiadomym jest w jaki sposób wygląda następnik. jest to zbiór skadający się z elementów od 1 do i+1 - len(y) +2 dlatego że (+1 bo funckja range zawsze dąży do elementu o jeden mniejszego i kolejne +1 bo mówimi o zbiorze i-elementowych który różni się od porpzedniego długością o 1.
            return list(range(1, len(y) + 2))

    # --------------------------------------------------------------
    # PREDECESSOR

    elif operation == "predecessor":

        if x.index(y) - 1 >= 0: #Podobna sprawa jak z successorem. jeśli możemy zmniejszyc index i nie wyjdziemy poza listę, to poprostu zmniejszamy index i pobieramy wartość kryjącą się za nim w liście x
            return x[index - 1]

        elif len(y) == 0: #jeśli długość listy jest równa 0 to oznacza że lista jest pusta. czyli jest to zbiór pusty! a zbiór pusty nie ma poprzednika
            return None

        else:
            return list(range(n, n - (len(y) - 1), -1).__reversed__()) #w innych przypadkach wiadomym jest jak wygląda zbiór i-1 elementowy. [...n-2 ,n-1 ,n ]
                                                                    #więc zaczynamy tworzyć listę od wartości n, lista ma długość n - (len(y) + 1  , i każdy kolejny element jest o jeden mniejszy jak we wzorze. następnie obracamy listę aby pasowała do wyzanczonego przezemnie porządku leksykograficznego
    # --------------------------------------------------------------


def tests():
    pass


# --------#----------#----------#---------#---------#---------#----------#
#  https://www.easycalculation.com/algebra/proper-subset-calculator.php  #
# --------#----------#----------#---------#---------#---------#----------#

def main():

    s = [1,3]
    n = 3
    #rank = 1

    r = ranked(s,n)

    rank = int(r)
    predecessor = op(rank, n, "predecessor")
    unranked = op(rank, n, "unranked")
    successor = op(rank, n, "successor")

    print(f"       Rank: {int(r)}")
    print(f"Predecessor: {predecessor}")
    print(f"   Unranked: {unranked}")
    print(f"  Successor: {successor}")


main()
