


import math



def rank(T,n):
    r = 0
    k = len(T)
    T.insert(0,0)
    for i in range(1, k+1):
        if T[i-1] + 1 <= T[i] - 1:
            for j in range(T[i-1]+1, T[i]):
                r += math.comb(n-j, k-i)    #do tego momentu liczmy liczbę rankingową tego zbioru pośród wszytskich podzbiorów o długości 2

    # od tego momentu liczby liczbę rankingową wszystkich podzbiorów zbioru n-elementowego {1,2,...,n}  ale tylko takich których długość jest mniejsz od długości już zbadengo podzbioru!
    i = 0
    while i < k:
        r += math.comb(n, i)
        i += 1
    print(f"Rank= {r}") #zsumowanyw wynik wskazuje nam na liczbe rankingową.
    return r



def unrank(rank, n):
    k = 0
    if rank == 0:  #jeśli rank jest zero to znaczy że mówimy o zbiorze pustym
        U = []
        return U

    while math.comb(n,k) <= rank:  # jedziemy liczymy ilość wszytskich podzbiorów x-elementowych zaczynając od 0. i przy każdej iteracji odejmujemy je od liczby rankingowej. następnie
        rank -= math.comb(n,k)     # gdy kombinacja jest większa od rank wtedy się dalsza/kolejna iteracja nie wykona. i liczba k oznacza w ilu elementowym podzbiorze znajduje się nasz szukany przez nas zbiór
        k += 1                     # a liczba rank mówi że jest rank+1 elementem w tym podzbiorze ideksując od liczby 1

    T = [0]*k #tworzymy podzbiór k -elementowy którego następnie elementy będziemy odpowiedni podmieniac.

    x = 1
    for i in range(1, k+1):
        while math.comb(n - x, k - i ) <= rank: #Przechodzimy przez wszystkie podzbiory aż liczba rankingowa będzie 0 wtedy wiemy, że już jesteśmy na odpowiednim podzbiorze
            rank -= math.comb(n - x, k - i )
            x += 1
        T[i-1] = x
        x += 1

    #print(f"unrank = {T}")
    return T



def successor(rank,n):
    T = unrank(rank,n)
    U = T.copy()
    k = len(T)
    i = k
    if len(U) == 0: #jeśli U to zbiór pusty to następnikiem jest  [1]
        U.append(1)
        #print(f"Successor X = {U}")
        return U

    while i >= 0 and T[i-1] == n - k + i :
        i -= 1

    if k == n:   #jeśli liczba elementów jest rówa n to oznacza że jest to ostatni element a więc nie ma on następnika
        #print(f"Successor = {None}")
        return None
    elif sum(T) == sum(list(range(n,n-len(T),-1)))  : #jeśli suma danego podzbioru jest równa sumie elementów podzbioru o maksymalnych wartościach i o tej samej długości to znaczy że następnik będzie wyglaąd
        U.append(0)                                    # w ten sposób [1,..,k+1] (wcześniejsze k)
        for x in range(1,len(T)+2):
            U[x-1] = x
        #print(f"Successor X = {U}")
        return U
    else:
        for j in range(i, k+1):
           U[j-1] = T[i-1] + 1 + j - i #tutaj szukany jest następnik dla naszego podzbioru w tym samek k-elementowej rodzinie zbiorów.
        #print(f"Successor = {U}")
        return U

def predecessor(rank,n):
    if rank == 0:
        return None
    else:
        T = unrank(rank-1,n)
        return T

    # k = len(T)
    # U = T.copy()
    #
    # if k == 0:
    #     #print(f"Predecessor = {None}")
    #     return None
    # i = k - 1
    # while i >= 0 and T[i] == i + n - k+ 1:
    #     i -= 1
    # if sum(T) == sum(list(range(1, len(T)+1, 1))):
    #     U.pop()
    #     c = -1
    #     for x in range(n, n-len(U)  ,-1):
    #         U[c] = x
    #         c -= 1
    #     print(f"Predecessor Xd = {U}")
    #     return U
    # else:
    #    ###

def succ(rank,n):
    if rank == (2**n)-1:
        return None
    else:
        T = unrank(rank+1,n)
        return T


def main():

    n = 8
    T = [1,3,4,5]
    print(f"T = {T}")
    x = rank(T,n)


    print(f"Rank = {x}")
    print()

    print(f"Predeccessor = {predecessor(x, n)}")
    print(f"Unrank = {unrank(x, n)}")
    print(f"Successor =  {successor(x,n)}")












main()