"""
Test module for ko_ak_zad1.py
"""

from ko_ak_zad1 import *
import unittest
import random

class tests(unittest.TestCase):

    def test_correctValues(self):
        self.assertEqual(ranked([1,2,5,6],6),47)
        self.assertEqual(op(47,6,"unranked"),[1,2,5,6])
        self.assertEqual(op(47,6,"predecessor"),[1,2,4,6] )
        self.assertEqual(op(47,6, "successor"), [1,3,4,5] )

    def test_randomCorrectValues(self):
        self.n = 12
        self.x = list(range(1,int(random.randrange(self.n+1))))
        self.y = random.randrange(self.n)
        self.assertEqual( op(int(ranked(self.x,self.n)),self.n,"unranked") , self.x)
        self.assertEqual( ranked(op(self.y,self.n,"unranked"),self.n) , self.y )

    def test_incorrectRankValues_test(self):
        with self.assertRaises(IndexError):
            self.n = 2
            self.rank = 5
            self.assertEqual(op(self.rank, self.n, "unranked"))
            self.assertEqual(op(self.rank, self.n, "predecessor"))
            self.assertEqual(op(self.rank, self.n, "successor"))


    def test_ExtremeValues_predeccessor_successor(self):
        self.assertEqual(op(0, 2, "predecessor"), None)
        self.assertEqual(op(3, 2, "successor"), None)


    def test_predeccessor(self):
        self.rank = random.randint(1,2**4)
        self.assertEqual(op(self.rank, 8, "predecessor"), op(self.rank -1 ,8,"unranked"))

    def test_successor(self):
        self.n = 6
        self.rank = random.randint(1,(2**self.n)-1)
        self.assertEqual(op(self.rank,self.n,"successor") , op(self.rank + 1, self.n , "unranked"))

